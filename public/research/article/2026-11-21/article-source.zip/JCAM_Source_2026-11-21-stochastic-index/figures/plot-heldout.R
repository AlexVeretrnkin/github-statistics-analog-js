# From manuscript directory: Rscript --vanilla figures/plot-heldout.R
d <- read.csv('figures/heldout-series.csv')
ii <- read.csv('supplement-data/index/intervals/interval-predictions.csv')
ii <- subset(ii,model=='SARIMA' & route=='components' & block==1 & horizon==6)
for (metric in c('npm-downloads','github-stars','index')) {
  ix<-metric=='index';npm<-metric=='npm-downloads';unit<-if(npm)1e6 else 1
  pdf(paste0('figures/',metric,'-backtest.pdf'),width=7,height=4.7,useDingbats=FALSE)
  par(mfrow=c(3,1),mar=c(.25,4.5,1.12,.9),oma=c(2.2,.8,2.15,.1),mgp=c(2,.45,0),tcl=-.18)
  for(f in c('React','Angular','Vue')) {
    if(ix){
      x<-ii[ii$framework==f,];x<-x[order(x$date),]; y<-x$actual; fc<-x$point;n<-rep(NA_real_,24)
      stopifnot(nrow(x)==24,!anyDuplicated(x$origin));ticks<-c(1,7,13,19,24)
    }else{
      x<-d[d$metric==metric & d$framework==f,];x<-x[order(x$date),]
      y<-x$observed/unit;fc<-x$sarima/unit;n<-x$persistence/unit
      stopifnot(nrow(x)==36,sum(is.finite(fc))==12);ticks<-c(1,12,24,36)
    }
    lo<-x$lo80/unit;hi<-x$hi80/unit;t<-seq_along(y);h<-which(is.finite(fc));miss<-h[y[h]<lo[h]|y[h]>hi[h]]
    stopifnot(all(lo[h]>0),all(lo[h]<=fc[h] & fc[h]<=hi[h]),all(y>0))
    ran<-range(c(y,fc,n,lo,hi),finite=TRUE);plot(t,y,log='y',type='n',axes=FALSE,xlab='',ylab='',ylim=ran)
    powers<-seq(floor(log10(ran[1])),ceiling(log10(ran[2])))
    at<-sort(as.numeric(outer(c(1,2,5),10^powers)));at<-at[at>=ran[1] & at<=ran[2]]
    if(length(at)<3)at<-pretty(ran,n=4)
    at<-at[at>=ran[1] & at<=ran[2]]
    if(length(at)>5)at<-at[round(seq(1,length(at),length.out=5))]
    abline(h=at,col='grey91');axis(2,at=at,labels=format(at,trim=TRUE,scientific=FALSE,big.mark=','),las=1,cex.axis=.85)
    polygon(c(h,rev(h)),c(lo[h],rev(hi[h])),col='#F7DAB5',border=NA)
    path<-if(ix)h else c(24,h)
    if(!ix){abline(v=24.5,col='grey35',lty=3);lines(path,c(y[24],n[h]),col='grey40',lty=4,lwd=1.4)}
    lines(t,y,col='#00526F',lwd=1.8);lines(path,if(ix)fc else c(y[24],fc[h]),col='#9A430B',lty=2,lwd=1.8)
    if(length(miss))points(miss,y[miss],pch=4,cex=.9,lwd=1.7,col='black')
    mtext(f,side=3,adj=0,line=.05,cex=.87,font=2)
    if(f=='Vue')axis(1,at=ticks,labels=format(as.Date(x$date[ticks]),'%b %Y'),cex.axis=.85)
  }
  mtext(if(npm)'Monthly downloads (millions)' else if(ix)'Index (50/50)' else 'Monthly star increments',side=2,outer=TRUE,line=-.45,cex=.83)
  par(fig=c(0,1,0,1),new=TRUE,oma=rep(0,4),mar=rep(0,4));plot.new()
  labels<-c('Observed',if(ix)'Component SARIMA' else 'SARIMA forecast','80% prediction interval','Outside interval')
  cols<-c('#00526F','#9A430B','#F7DAB5','black');lt<-c(1,2,NA,NA);pt<-c(NA,NA,15,4)
  if(!ix){labels<-c(labels,'Persistence');cols<-c(cols,'grey40');lt<-c(lt,4);pt<-c(pt,NA)}
  legend('top',labels,horiz=TRUE,bty='n',lty=lt,pch=pt,col=cols,lwd=1.7,cex=.88,x.intersp=.45)
  dev.off()
}
